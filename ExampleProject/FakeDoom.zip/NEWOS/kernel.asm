[org 0x1000]
; FAKE DOOM - block-built 16-bit raycaster
mov ax,0
mov ds,ax
mov es,ax
cli
mov ax,0
mov ss,ax
mov sp,0x7c00
sti
jmp after_include_9201
%include "hellgate_engine.asm"
after_include_9201:
mov ax, 0x0013
int 0x10
mov ah, 0x01
mov cx, 0x2000
int 0x10
mov dx,0x03c8
mov al,1
out dx,al
inc dx
mov al,10
out dx,al
mov al,0
out dx,al
mov al,0
out dx,al
mov dx,0x03c8
mov al,2
out dx,al
inc dx
mov al,22
out dx,al
mov al,2
out dx,al
mov al,2
out dx,al
mov dx,0x03c8
mov al,3
out dx,al
inc dx
mov al,38
out dx,al
mov al,6
out dx,al
mov al,2
out dx,al
mov dx,0x03c8
mov al,4
out dx,al
inc dx
mov al,63
out dx,al
mov al,0
out dx,al
mov al,0
out dx,al
mov dx,0x03c8
mov al,5
out dx,al
inc dx
mov al,63
out dx,al
mov al,22
out dx,al
mov al,0
out dx,al
mov dx,0x03c8
mov al,6
out dx,al
inc dx
mov al,24
out dx,al
mov al,12
out dx,al
mov al,5
out dx,al
mov dx,0x03c8
mov al,7
out dx,al
inc dx
mov al,38
out dx,al
mov al,38
out dx,al
mov al,42
out dx,al
mov dx,0x03c8
mov al,8
out dx,al
inc dx
mov al,12
out dx,al
mov al,10
out dx,al
mov al,10
out dx,al
mov dx,0x03c8
mov al,9
out dx,al
inc dx
mov al,5
out dx,al
mov al,8
out dx,al
mov al,16
out dx,al
mov dx,0x03c8
mov al,10
out dx,al
inc dx
mov al,0
out dx,al
mov al,55
out dx,al
mov al,12
out dx,al
mov dx,0x03c8
mov al,14
out dx,al
inc dx
mov al,63
out dx,al
mov al,52
out dx,al
mov al,8
out dx,al
mov dx,0x03c8
mov al,15
out dx,al
inc dx
mov al,63
out dx,al
mov al,63
out dx,al
mov al,63
out dx,al
mov dx,0x03c8
mov al,11
out dx,al
inc dx
mov al,12
out dx,al
mov al,34
out dx,al
mov al,55
out dx,al
mov dx,0x03c8
mov al,12
out dx,al
inc dx
mov al,18
out dx,al
mov al,46
out dx,al
mov al,63
out dx,al
mov dx,0x03c8
mov al,13
out dx,al
inc dx
mov al,35
out dx,al
mov al,58
out dx,al
mov al,63
out dx,al
cld
push es
mov ax, 0xa000
mov es, ax
xor di, di
xor ax, ax
mov cx, 32000
rep stosw
pop es
mov ah, 0x02
mov bh, 0
mov dh, 5
mov dl, 10
int 0x10
mov si, msg_gfx_9301
mov bl, 12
call print_string_gfx_9301
jmp after_gfx_9301
msg_gfx_9301 db 70, 65, 75, 69, 32, 68, 79, 79, 77, 0
print_string_gfx_9301:
    pusha
    cld
.loop:
    lodsb
    or al, al
    jz .done
    mov ah, 0x0e
    xor bh, bh
    int 0x10
    jmp .loop
.done:
    popa
    ret
after_gfx_9301:
mov ah, 0x02
mov bh, 0
mov dh, 8
mov dl, 3
int 0x10
mov si, msg_gfx_9302
mov bl, 15
call print_string_gfx_9302
jmp after_gfx_9302
msg_gfx_9302 db 87, 47, 83, 32, 77, 79, 86, 69, 32, 32, 65, 47, 68, 32, 84, 85, 82, 78, 32, 32, 81, 47, 69, 32, 83, 84, 82, 65, 70, 69, 0
print_string_gfx_9302:
    pusha
    cld
.loop:
    lodsb
    or al, al
    jz .done
    mov ah, 0x0e
    xor bh, bh
    int 0x10
    jmp .loop
.done:
    popa
    ret
after_gfx_9302:
mov ah, 0x02
mov bh, 0
mov dh, 10
mov dl, 3
int 0x10
mov si, msg_gfx_9303
mov bl, 15
call print_string_gfx_9303
jmp after_gfx_9303
msg_gfx_9303 db 83, 80, 65, 67, 69, 32, 70, 73, 82, 69, 32, 32, 82, 32, 82, 69, 83, 84, 65, 82, 84, 32, 32, 69, 83, 67, 32, 81, 85, 73, 84, 0
print_string_gfx_9303:
    pusha
    cld
.loop:
    lodsb
    or al, al
    jz .done
    mov ah, 0x0e
    xor bh, bh
    int 0x10
    jmp .loop
.done:
    popa
    ret
after_gfx_9303:
mov ah, 0x02
mov bh, 0
mov dh, 14
mov dl, 3
int 0x10
mov si, msg_gfx_9304
mov bl, 10
call print_string_gfx_9304
jmp after_gfx_9304
msg_gfx_9304 db 83, 85, 82, 86, 73, 86, 69, 32, 50, 53, 48, 32, 76, 69, 86, 69, 76, 83, 32, 79, 70, 32, 68, 69, 77, 79, 78, 83, 46, 0
print_string_gfx_9304:
    pusha
    cld
.loop:
    lodsb
    or al, al
    jz .done
    mov ah, 0x0e
    xor bh, bh
    int 0x10
    jmp .loop
.done:
    popa
    ret
after_gfx_9304:
mov ah, 0x02
mov bh, 0
mov dh, 18
mov dl, 4
int 0x10
mov si, msg_gfx_9305
mov bl, 14
call print_string_gfx_9305
jmp after_gfx_9305
msg_gfx_9305 db 80, 82, 69, 83, 83, 32, 65, 78, 89, 32, 75, 69, 89, 32, 84, 79, 32, 69, 78, 84, 69, 82, 32, 70, 65, 75, 69, 32, 68, 79, 79, 77, 0
print_string_gfx_9305:
    pusha
    cld
.loop:
    lodsb
    or al, al
    jz .done
    mov ah, 0x0e
    xor bh, bh
    int 0x10
    jmp .loop
.done:
    popa
    ret
after_gfx_9305:
mov ah, 0x00
int 0x16
call hg_install_keyboard
call new_game
mov bx, 330
or bx, bx
jz .beep_done_9306
mov al, 0xb6
out 0x43, al
mov dx, 0x0012
mov ax, 0x34dc
div bx
out 0x42, al
mov al, ah
out 0x42, al
in al, 0x61
or al, 3
out 0x61, al
mov ax, 20
mov cx, 1000
mul cx
mov cx, dx
mov dx, ax
mov ah, 0x86
int 0x15
in al, 0x61
and al, 0xfc
out 0x61, al
.beep_done_9306:
mov bx, 440
or bx, bx
jz .beep_done_9307
mov al, 0xb6
out 0x43, al
mov dx, 0x0012
mov ax, 0x34dc
div bx
out 0x42, al
mov al, ah
out 0x42, al
in al, 0x61
or al, 3
out 0x61, al
mov ax, 25
mov cx, 1000
mul cx
mov cx, dx
mov dx, ax
mov ah, 0x86
int 0x15
in al, 0x61
and al, 0xfc
out 0x61, al
.beep_done_9307:
hellgate_game_loop:
call game_input
call game_update
call game_render
jmp hellgate_game_loop
