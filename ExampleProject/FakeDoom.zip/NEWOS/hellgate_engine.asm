; Link the block-defined Fake DOOM state and map
jmp after_include_9001
%include "hellgate_data.asm"
after_include_9001:
; The independent visual function chains follow
jmp __oc_functions_end
new_game:
; Start a fresh 250-level campaign at level one
mov word [score], 0
mov byte [current_level],1
mov byte [music_index],0
mov byte [music_enabled],1
mov ah,0x00
int 0x1a
mov [random_seed],dx
call hg_start_level
ret
game_input:
; Apply held-key state every frame for smooth movement and collision
test word [keys_down],0x0100
jnz .quit_game
cmp byte [game_state],3
jne .not_level_complete
cmp byte [level_continue_armed],0
jne .level_wait_key
cmp word [keys_down],0
jne .input_done
mov byte [level_continue_armed],1
mov byte [key_ready],0
jmp .input_done
.level_wait_key:
cmp byte [key_ready],0
je .input_done
mov byte [key_ready],0
mov byte [level_continue_armed],0
call hg_advance_level
jmp .input_done
.not_level_complete:
test word [keys_down],0x0080
jz .not_restart
call new_game
and word [keys_down],0xff7f
.not_restart:
cmp byte [game_state],0
jne .input_done
test byte [frame_count],1
jnz .turn_done
test word [keys_down],0x0004
jz .not_turn_left
dec byte [player_angle]
.not_turn_left:
test word [keys_down],0x0008
jz .turn_done
inc byte [player_angle]
.turn_done:
and byte [player_angle],63
test word [keys_down],0x0001
jz .not_forward
call .direction
call .try_move
.not_forward:
test word [keys_down],0x0002
jz .not_backward
call .direction
neg dx
neg cx
call .try_move
.not_backward:
test word [keys_down],0x0010
jz .not_strafe_left
mov al,[player_angle]
sub al,16
and al,63
call .direction_for_al
call .try_move
.not_strafe_left:
test word [keys_down],0x0020
jz .not_strafe_right
mov al,[player_angle]
add al,16
and al,63
call .direction_for_al
call .try_move
.not_strafe_right:
test word [keys_down],0x0040
jz .input_done
call game_shoot
jmp .input_done
.quit_game:
in al,0x61
and al,0xfc
out 0x61,al
mov ax,0x0003
int 0x10
cli
.quit_halt:
hlt
jmp .quit_halt
.direction:
mov al,[player_angle]
.direction_for_al:
xor bx,bx
mov bl,al
shl bx,1
mov dx,[cos_table+bx]
sar dx,5
mov cx,[sin_table+bx]
sar cx,5
ret
.try_move:
mov ax,[player_x]
add ax,dx
mov [candidate_x],ax
mov ax,[player_y]
add ax,cx
mov [candidate_y],ax
mov ax,[candidate_x]
mov bl,ah
xor bh,bh
mov ax,[candidate_y]
mov al,ah
xor ah,ah
shl ax,4
add bx,ax
cmp byte [world_map+bx],0
jne .move_blocked
mov ax,[candidate_x]
mov [player_x],ax
mov ax,[candidate_y]
mov [player_y],ax
.move_blocked:
ret
.input_done:
ret
game_update:
cmp word [shot_cooldown],0
je .cooldown_done_1201
dec word [shot_cooldown]
.cooldown_done_1201:
inc word [frame_count]
mov ax,[random_seed]
mov bx,25173
mul bx
add ax,13849
mov [random_seed],ax
; Move up to eight active monsters and update the soundtrack
cmp byte [game_state],0
jne .update_done
xor si,si
xor di,di
.enemy_loop:
call .enemy_step
inc si
add di,2
cmp si,8
jb .enemy_loop
jmp .update_done
.enemy_step:
cmp byte [enemy_health+si],0
je .enemy_return
mov ax,[enemy_x+di]
mov [candidate_x],ax
mov ax,[enemy_y+di]
mov [candidate_y],ax
test byte [frame_count],15
jnz .enemy_attack
mov ax,[candidate_x]
cmp ax,[player_x]
je .enemy_step_y
ja .enemy_x_down
add ax,6
jmp .enemy_x_store
.enemy_x_down:
sub ax,6
.enemy_x_store:
mov [candidate_x],ax
.enemy_step_y:
mov ax,[candidate_y]
cmp ax,[player_y]
je .enemy_test_map
ja .enemy_y_down
add ax,6
jmp .enemy_y_store
.enemy_y_down:
sub ax,6
.enemy_y_store:
mov [candidate_y],ax
.enemy_test_map:
mov ax,[candidate_x]
mov bl,ah
xor bh,bh
mov ax,[candidate_y]
mov al,ah
xor ah,ah
shl ax,4
add bx,ax
cmp byte [world_map+bx],0
jne .enemy_attack
mov ax,[candidate_x]
mov [enemy_x+di],ax
mov ax,[candidate_y]
mov [enemy_y+di],ax
.enemy_attack:
mov ax,[enemy_x+di]
sub ax,[player_x]
jns .enemy_dx_ok
neg ax
.enemy_dx_ok:
mov dx,ax
mov ax,[enemy_y+di]
sub ax,[player_y]
jns .enemy_dy_ok
neg ax
.enemy_dy_ok:
add dx,ax
cmp dx,220
ja .enemy_return
test byte [frame_count],63
jnz .enemy_return
mov al,[player_health]
cmp al,2
jbe .player_died
sub al,2
mov [player_health],al
call hg_sound_hurt
jmp .enemy_return
.player_died:
mov byte [player_health],0
mov byte [game_state],1
mov byte [crosshair_color],0
call hg_sound_death
.enemy_return:
ret
.update_done:
call hg_music_update
ret
game_render:
; Clear a full off-screen frame without exposing partial drawing
push es
mov ax,0x2000
mov es,ax
xor di,di
mov ax,0x0909
mov cx,14400
cld
rep stosw
mov ax,0x0808
mov cx,14400
rep stosw
mov ax,0x0101
mov cx,3200
rep stosw
pop es
; Dispatch the raycaster or the death/victory screen
cmp byte [game_state],0
jne hg_render_state_screen
mov byte [crosshair_color],15
call hg_cast_world
call hg_draw_enemies
call hg_draw_weapon_hud
jmp hg_render_dispatch_done
hg_render_state_screen:
call hg_draw_weapon_hud
hg_render_dispatch_done:
jmp hg_render_helpers_end
; 40-column fixed-point wall raycaster and depth buffer
hg_cast_world:
mov byte [ray_column],0
hg_ray_column_loop:
mov al,[player_angle]
mov bl,[ray_column]
shr bl,1
add al,bl
sub al,10
and al,63
mov [ray_angle],al
mov ax,[player_x]
mov [ray_x],ax
mov ax,[player_y]
mov [ray_y],ax
mov cx,1
hg_ray_step_loop:
xor bx,bx
mov bl,[ray_angle]
shl bx,1
mov ax,[cos_table+bx]
sar ax,3
add [ray_x],ax
mov ax,[sin_table+bx]
sar ax,3
add [ray_y],ax
mov ax,[ray_x]
mov bl,ah
xor bh,bh
mov ax,[ray_y]
mov al,ah
xor ah,ah
shl ax,4
add bx,ax
mov al,[world_map+bx]
or al,al
jnz hg_ray_hit
inc cx
cmp cx,48
jb hg_ray_step_loop
mov al,1
hg_ray_hit:
mov [wall_tile],al
mov [ray_distance],cx
xor bx,bx
mov bl,[ray_column]
shl bx,1
mov [zbuffer+bx],cx
cmp byte [ray_column],20
jne hg_not_center_ray
mov [center_wall_distance],cx
hg_not_center_ray:
mov ax,1800
xor dx,dx
div cx
cmp ax,174
jbe hg_height_ready
mov ax,174
hg_height_ready:
mov [ray_height],ax
mov bx,ax
shr bx,1
mov ax,90
sub ax,bx
jns hg_top_ready
xor ax,ax
hg_top_ready:
mov [ray_top],ax
xor ax,ax
mov al,[ray_column]
shl ax,3
mov [draw_x],ax
mov ax,[ray_top]
mov [draw_y],ax
mov word [draw_w],8
mov ax,[ray_height]
mov [draw_h],ax
mov al,1
cmp cx,34
jae hg_ray_color_ready
mov al,2
cmp cx,24
jae hg_ray_color_ready
mov al,3
cmp cx,14
jae hg_ray_color_ready
mov al,5
hg_ray_color_ready:
mov [draw_color],al
call hg_fill_rect
inc byte [ray_column]
cmp byte [ray_column],40
jb hg_ray_column_loop
ret
; Project eight depth-tested monster billboards
hg_mul_shift8:
imul bx
mov al,ah
mov ah,dl
ret

hg_draw_enemies:
mov si,8
mov di,16
hg_draw_enemy_loop:
dec si
sub di,2
call hg_project_enemy
or si,si
jnz hg_draw_enemy_loop
ret

hg_project_enemy:
cmp byte [enemy_health+si],0
je hg_project_return
mov ax,si
mov [current_enemy],al
mov ax,[enemy_x+di]
sub ax,[player_x]
mov [vector_x],ax
mov ax,[enemy_y+di]
sub ax,[player_y]
mov [vector_y],ax
xor bx,bx
mov bl,[player_angle]
shl bx,1
push bx
mov ax,[vector_x]
mov bx,[cos_table+bx]
call hg_mul_shift8
mov cx,ax
pop bx
push bx
mov ax,[vector_y]
mov bx,[sin_table+bx]
call hg_mul_shift8
add cx,ax
mov [projection_forward],cx
pop bx
push bx
mov ax,[vector_y]
mov bx,[cos_table+bx]
call hg_mul_shift8
mov [projection_side],ax
pop bx
mov ax,[vector_x]
mov bx,[sin_table+bx]
call hg_mul_shift8
mov dx,[projection_side]
sub dx,ax
mov [projection_side],dx
cmp word [projection_forward],48
jle hg_project_return
mov ax,[projection_side]
mov bx,120
imul bx
idiv word [projection_forward]
add ax,160
cmp ax,-80
jl hg_project_return
cmp ax,400
jg hg_project_return
mov [projection_x],ax
mov ax,45000
xor dx,dx
div word [projection_forward]
cmp ax,10
jae hg_height_min_ready
mov ax,10
hg_height_min_ready:
cmp ax,90
jbe hg_enemy_height_ready
mov ax,90
hg_enemy_height_ready:
mov [projection_h],ax
mov bx,[projection_x]
cmp bx,0
jge hg_enemy_column_low_ok
xor bx,bx
hg_enemy_column_low_ok:
cmp bx,319
jle hg_enemy_column_ok
mov bx,319
hg_enemy_column_ok:
shr bx,3
shl bx,1
mov ax,[projection_forward]
shr ax,5
cmp ax,[zbuffer+bx]
jae hg_project_return
mov ax,[projection_h]
mov bx,ax
shr bx,1
mov [draw_w],bx
mov cx,[projection_x]
mov dx,bx
shr dx,1
sub cx,dx
mov [draw_x],cx
mov dx,90
mov cx,ax
shr cx,1
sub dx,cx
mov [draw_y],dx
mov cx,ax
xor dx,dx
mov bx,3
div bx
mov [enemy_head_h],ax
mov ax,cx
sub ax,[enemy_head_h]
mov [enemy_body_h],ax
mov ax,[draw_y]
add ax,[enemy_head_h]
mov [enemy_body_y],ax
mov ax,[projection_h]
xor dx,dx
mov bx,3
div bx
mov [enemy_body_w],ax
mov cx,[projection_x]
mov dx,ax
shr dx,1
sub cx,dx
mov [enemy_body_x],cx
xor bx,bx
mov bl,[current_enemy]
mov al,[enemy_health+bx]
add al,10
mov [draw_color],al
mov ax,[enemy_head_h]
mov [draw_h],ax
call hg_fill_rect
mov ax,[enemy_body_x]
mov [draw_x],ax
mov ax,[enemy_body_y]
mov [draw_y],ax
mov ax,[enemy_body_w]
mov [draw_w],ax
mov ax,[enemy_body_h]
mov [draw_h],ax
mov byte [draw_color],11
call hg_fill_rect
mov ax,[projection_h]
cmp ax,20
jb hg_project_return
mov word [draw_w],3
mov word [draw_h],2
mov byte [draw_color],14
mov ax,[projection_x]
sub ax,6
mov [draw_x],ax
mov ax,90
mov dx,[projection_h]
shr dx,1
sub ax,dx
mov dx,[enemy_head_h]
shr dx,1
add ax,dx
mov [draw_y],ax
call hg_fill_rect
add word [draw_x],9
call hg_fill_rect
hg_project_return:
ret
; Clipped rectangle drawing, weapon, muzzle flash, HUD, and messages
hg_fill_rect:
pusha
cmp word [draw_w],0
jle hg_fill_done
cmp word [draw_h],0
jle hg_fill_done
cmp word [draw_x],0
jge hg_fill_x_low
mov ax,[draw_x]
add [draw_w],ax
mov word [draw_x],0
hg_fill_x_low:
cmp word [draw_y],0
jge hg_fill_y_low
mov ax,[draw_y]
add [draw_h],ax
mov word [draw_y],0
hg_fill_y_low:
cmp word [draw_x],320
jge hg_fill_done
cmp word [draw_y],200
jge hg_fill_done
mov ax,320
sub ax,[draw_x]
cmp [draw_w],ax
jbe hg_fill_width_ok
mov [draw_w],ax
hg_fill_width_ok:
mov ax,200
sub ax,[draw_y]
cmp [draw_h],ax
jbe hg_fill_height_ok
mov [draw_h],ax
hg_fill_height_ok:
push es
mov ax,0x2000
mov es,ax
mov bx,[draw_y]
mov bp,[draw_h]
hg_fill_row:
mov ax,bx
mov di,320
mul di
add ax,[draw_x]
mov di,ax
mov al,[draw_color]
mov cx,[draw_w]
cld
rep stosb
inc bx
dec bp
jnz hg_fill_row
pop es
hg_fill_done:
popa
ret

hg_draw_weapon_hud:
cmp byte [game_state],0
jne hg_draw_end_screen
mov word [draw_x],140
mov word [draw_y],148
mov word [draw_w],40
mov word [draw_h],32
mov byte [draw_color],7
call hg_fill_rect
mov word [draw_x],153
mov word [draw_y],126
mov word [draw_w],14
mov word [draw_h],30
mov byte [draw_color],6
call hg_fill_rect
mov word [draw_x],147
mov word [draw_y],170
mov word [draw_w],26
mov word [draw_h],10
mov byte [draw_color],8
call hg_fill_rect
cmp byte [shot_flash],0
je hg_no_muzzle_flash
dec byte [shot_flash]
mov word [draw_x],149
mov word [draw_y],116
mov word [draw_w],22
mov word [draw_h],10
mov byte [draw_color],14
call hg_fill_rect
hg_no_muzzle_flash:
mov word [draw_x],0
mov word [draw_y],180
mov word [draw_w],320
mov word [draw_h],20
mov byte [draw_color],1
call hg_fill_rect
mov word [draw_x],6
mov word [draw_y],192
xor ax,ax
mov al,[player_health]
mov [draw_w],ax
mov word [draw_h],5
mov byte [draw_color],10
cmp byte [player_health],25
ja hg_health_color_ready
mov byte [draw_color],4
hg_health_color_ready:
call hg_fill_rect
mov word [text_x],6
mov word [text_y],182
mov byte [text_color],15
mov si,hud_hp_text
call hg_print_string
xor ax,ax
mov al,[player_health]
call hg_print_uint
mov word [text_x],70
mov word [text_y],182
mov si,hud_level_text
call hg_print_string
xor ax,ax
mov al,[current_level]
call hg_print_uint
mov word [text_x],126
mov word [text_y],182
mov si,hud_enemy_text
call hg_print_string
mov ax,[level_enemies_remaining]
call hg_print_uint
mov word [text_x],190
mov word [text_y],182
mov si,hud_score_text
call hg_print_string
mov ax,[score]
call hg_print_uint
ret

hg_draw_end_screen:
mov byte [crosshair_color],0
mov word [draw_x],35
mov word [draw_y],48
mov word [draw_w],250
mov word [draw_h],92
mov byte [draw_color],1
call hg_fill_rect
mov word [draw_x],40
mov word [draw_y],53
mov word [draw_w],240
mov word [draw_h],82
mov byte [draw_color],0
call hg_fill_rect
mov word [text_x],104
mov word [text_y],64
mov byte [text_color],15
cmp byte [game_state],3
je hg_level_complete_message
cmp byte [game_state],2
je hg_win_message
mov si,dead_text
jmp hg_state_message
hg_win_message:
mov si,win_text
hg_state_message:
call hg_print_string
mov word [text_x],82
mov word [text_y],96
mov si,restart_text
call hg_print_string
ret

hg_level_complete_message:
mov word [text_x],118
mov si,level_complete_text
call hg_print_string
mov word [text_x],76
mov word [text_y],96
mov si,next_level_text
call hg_print_string
ret

hg_print_string:
pusha
cld
hg_print_string_loop:
lodsb
or al,al
jz hg_print_string_done
call hg_draw_char
jmp hg_print_string_loop
hg_print_string_done:
popa
ret

hg_print_uint:
pusha
xor cx,cx
mov bx,10
hg_uint_convert:
xor dx,dx
div bx
push dx
inc cx
or ax,ax
jnz hg_uint_convert
hg_uint_output:
pop ax
add al,'0'
call hg_draw_char
loop hg_uint_output
popa
ret

hg_draw_char:
pusha
cmp al,'0'
jb hg_char_letter
cmp al,'9'
ja hg_char_letter
sub al,'0'
jmp hg_char_index_ready
hg_char_letter:
cmp al,'A'
jb hg_char_colon
cmp al,'Z'
ja hg_char_colon
sub al,'A'-10
jmp hg_char_index_ready
hg_char_colon:
cmp al,':'
jne hg_char_advance_only
mov al,36
hg_char_index_ready:
xor ah,ah
mov bl,7
mul bl
mov si,hg_font5x7
add si,ax
push es
mov ax,0x2000
mov es,ax
xor bx,bx
hg_char_row:
mov ax,[text_y]
add ax,bx
mov dx,320
mul dx
add ax,[text_x]
mov di,ax
mov dl,[si+bx]
mov dh,5
hg_char_bit:
test dl,0x10
jz hg_char_skip_pixel
mov al,[text_color]
mov [es:di],al
hg_char_skip_pixel:
shl dl,1
inc di
dec dh
jnz hg_char_bit
inc bx
cmp bx,7
jb hg_char_row
pop es
hg_char_advance_only:
popa
add word [text_x],6
ret

hg_font5x7:
db 14,17,19,21,25,17,14,4,12,4,4,4,4,14,14,17,1,2,4,8,31,30,1,1,14,1,1,30,2,6,10,18,31,2,2,31,16,16,30,1,1,30,14,16,16,30,17,17,14,31,1,2,4,8,8,8,14,17,17,14,17,17,14,14,17,17,15,1,1,14
db 14,17,17,31,17,17,17,30,17,17,30,17,17,30,15,16,16,16,16,16,15,30,17,17,17,17,17,30,31,16,16,30,16,16,31,31,16,16,30,16,16,16,15,16,16,23,17,17,15,17,17,17,31,17,17,17,14,4,4,4,4,4,14,7,2,2,2,18,18,12,17,18,20,24,20,18,17,16,16,16,16,16,16,31,17,27,21,21,17,17,17,17,25,21,19,17,17,17,14,17,17,17,17,17,14,30,17,17,30,16,16,16,14,17,17,17,21,18,13,30,17,17,30,20,18,17,15,16,16,14,1,1,30,31,4,4,4,4,4,4,17,17,17,17,17,17,14,17,17,17,17,17,10,4,17,17,17,21,21,27,17,17,17,10,4,10,17,17,17,17,17,10,4,4,4,4,31,1,2,4,8,16,31
db 0,4,4,0,4,4,0
hg_render_helpers_end:
; Draw the crosshair, wait for retrace, then present one complete frame
cmp byte [crosshair_color],0
je hg_crosshair_done
mov word [draw_x],156
mov word [draw_y],89
mov word [draw_w],9
mov word [draw_h],2
mov al,[crosshair_color]
mov [draw_color],al
call hg_fill_rect
mov word [draw_x],159
mov word [draw_y],86
mov word [draw_w],2
mov word [draw_h],9
call hg_fill_rect
hg_crosshair_done:
mov dx,0x03da
hg_present_wait_not_retrace:
in al,dx
test al,8
jnz hg_present_wait_not_retrace
hg_present_wait_retrace:
in al,dx
test al,8
jz hg_present_wait_retrace
push ds
push es
mov ax,0x2000
mov ds,ax
mov ax,0xa000
mov es,ax
xor si,si
xor di,di
mov cx,32000
cld
rep movsw
pop es
pop ds
ret
game_shoot:
; Hitscan the nearest visible monster inside the crosshair
cmp byte [game_state],0
jne .shoot_ignored
cmp word [shot_cooldown],0
jne .shoot_ignored
mov word [shot_cooldown],6
mov byte [shot_flash],2
mov word [best_distance],0xffff
mov byte [best_enemy],0xff
xor si,si
xor di,di
.shoot_test_loop:
call .test_enemy
inc si
add di,2
cmp si,8
jb .shoot_test_loop
cmp byte [best_enemy],0xff
je .shot_complete
xor bx,bx
mov bl,[best_enemy]
dec byte [enemy_health+bx]
call hg_sound_hit
cmp byte [enemy_health+bx],0
jne .shot_complete
dec byte [enemies_alive]
dec word [level_enemies_remaining]
cmp word [score],65435
ja .score_ready
add word [score],100
.score_ready:
cmp word [level_enemies_remaining],0
je .level_complete
cmp word [spawn_remaining],0
je .shot_complete
xor si,si
mov si,bx
mov di,bx
shl di,1
call hg_spawn_enemy_slot
dec word [spawn_remaining]
inc byte [enemies_alive]
jmp .shot_complete
.level_complete:
call hg_finish_level
.shot_complete:
jmp .shoot_block_end
.shoot_ignored:
ret
.test_enemy:
cmp byte [enemy_health+si],0
je .test_return
mov ax,[enemy_x+di]
sub ax,[player_x]
mov [vector_x],ax
mov ax,[enemy_y+di]
sub ax,[player_y]
mov [vector_y],ax
xor bx,bx
mov bl,[player_angle]
shl bx,1
push bx
mov ax,[vector_x]
mov bx,[cos_table+bx]
call hg_mul_shift8
mov cx,ax
pop bx
push bx
mov ax,[vector_y]
mov bx,[sin_table+bx]
call hg_mul_shift8
add cx,ax
mov [projection_forward],cx
pop bx
push bx
mov ax,[vector_y]
mov bx,[cos_table+bx]
call hg_mul_shift8
mov [projection_side],ax
pop bx
mov ax,[vector_x]
mov bx,[sin_table+bx]
call hg_mul_shift8
mov dx,[projection_side]
sub dx,ax
mov [projection_side],dx
cmp word [projection_forward],32
jle .test_return
mov ax,[projection_side]
test ax,ax
jns .side_absolute
neg ax
.side_absolute:
mov dx,[projection_forward]
shr dx,3
add dx,20
cmp ax,dx
ja .test_return
mov ax,[projection_forward]
shr ax,5
cmp ax,[center_wall_distance]
jae .test_return
mov ax,[projection_forward]
cmp ax,[best_distance]
jae .test_return
mov [best_distance],ax
mov ax,si
mov [best_enemy],al
.test_return:
ret
.shoot_block_end:
mov word [music_timer],0
mov bx, 720
or bx, bx
jz .beep_done_1401
mov al, 0xb6
out 0x43, al
mov dx, 0x0012
mov ax, 0x34dc
div bx
out 0x42, al
mov al, ah
out 0x42, al
in al, 0x61
or al, 3
out 0x61, al
mov ax, 8
mov cx, 1000
mul cx
mov cx, dx
mov dx, ax
mov ah, 0x86
int 0x15
in al, 0x61
and al, 0xfc
out 0x61, al
.beep_done_1401:
ret
hg_audio_library:
; PC-speaker effects and non-blocking ambient soundtrack
jmp hg_audio_library_end
hg_tone:
pusha
or bx,bx
jz hg_tone_done
mov al,0xb6
out 0x43,al
mov dx,0x0012
mov ax,0x34dc
div bx
out 0x42,al
mov al,ah
out 0x42,al
in al,0x61
or al,3
out 0x61,al
xor cx,cx
mov dx,si
mov ah,0x86
int 0x15
in al,0x61
and al,0xfc
out 0x61,al
mov word [music_timer],0
hg_tone_done:
popa
ret
hg_sound_hit:
pusha
mov bx,180
mov si,3500
call hg_tone
mov bx,120
mov si,3000
call hg_tone
popa
ret
hg_sound_hurt:
pusha
mov bx,90
mov si,5500
call hg_tone
popa
ret
hg_sound_death:
pusha
mov bx,150
mov si,9000
call hg_tone
mov bx,100
mov si,11000
call hg_tone
mov bx,60
mov si,14000
call hg_tone
popa
ret
hg_sound_win:
pusha
mov bx,330
mov si,7000
call hg_tone
mov bx,440
mov si,7000
call hg_tone
mov bx,660
mov si,11000
call hg_tone
popa
ret
hg_music_update:
pusha
cmp byte [music_enabled],0
je hg_music_silence
mov ah,0x00
int 0x1a
cmp dx,[music_last_tick]
je hg_music_done
mov [music_last_tick],dx
cmp word [music_timer],0
je hg_music_next_note
dec word [music_timer]
jmp hg_music_done
hg_music_next_note:
xor bx,bx
mov bl,[music_index]
mov al,[music_durations+bx]
xor ah,ah
mov [music_timer],ax
shl bx,1
mov bx,[music_notes+bx]
call hg_music_set_tone
inc byte [music_index]
and byte [music_index],31
jmp hg_music_done
hg_music_silence:
xor bx,bx
call hg_music_set_tone
hg_music_done:
popa
ret

hg_music_set_tone:
pusha
in al,0x61
and al,0xfc
out 0x61,al
or bx,bx
jz hg_music_tone_done
mov al,0xb6
out 0x43,al
mov dx,0x0012
mov ax,0x34dc
div bx
out 0x42,al
mov al,ah
out 0x42,al
in al,0x61
or al,3
out 0x61,al
hg_music_tone_done:
popa
ret

music_notes dw 110,0,131,0,147,0,131,0,98,0,123,0,110,0,82,0,110,0,147,0,165,0,147,0,123,0,98,0,73,0
music_durations db 10,5,10,5,10,5,10,8,12,5,10,5,10,8,14,10,10,5,10,5,10,5,10,8,12,5,10,5,10,8,16,12
hg_audio_library_end:
ret
hg_keyboard_library:
; IRQ keyboard driver records press/release state for fluid held controls
jmp hg_keyboard_library_end
hg_install_keyboard:
cli
push es
xor ax,ax
mov es,ax
mov word [es:0x24],hg_keyboard_isr
mov word [es:0x26],cs
pop es
mov word [keys_down],0
mov byte [key_extended],0
sti
ret

hg_keyboard_isr:
pusha
push ds
xor ax,ax
mov ds,ax
in al,0x60
cmp al,0xe0
jne hg_keyboard_decode
mov byte [key_extended],1
jmp hg_keyboard_ack
hg_keyboard_decode:
mov ah,al
and al,0x7f
test ah,0x80
jnz hg_keyboard_map_key
mov [last_key],al
mov byte [key_ready],1
hg_keyboard_map_key:
xor dx,dx
cmp al,0x11
jne hg_key_not_w
mov dx,0x0001
jmp hg_key_apply
hg_key_not_w:
cmp al,0x1f
jne hg_key_not_s
mov dx,0x0002
jmp hg_key_apply
hg_key_not_s:
cmp al,0x1e
jne hg_key_not_a
mov dx,0x0004
jmp hg_key_apply
hg_key_not_a:
cmp al,0x20
jne hg_key_not_d
mov dx,0x0008
jmp hg_key_apply
hg_key_not_d:
cmp al,0x10
jne hg_key_not_q
mov dx,0x0010
jmp hg_key_apply
hg_key_not_q:
cmp al,0x12
jne hg_key_not_e
mov dx,0x0020
jmp hg_key_apply
hg_key_not_e:
cmp al,0x39
jne hg_key_not_space
mov dx,0x0040
jmp hg_key_apply
hg_key_not_space:
cmp al,0x13
jne hg_key_not_r
mov dx,0x0080
jmp hg_key_apply
hg_key_not_r:
cmp al,0x01
jne hg_key_not_escape
mov dx,0x0100
jmp hg_key_apply
hg_key_not_escape:
cmp al,0x48
jne hg_key_not_up
mov dx,0x0001
jmp hg_key_apply
hg_key_not_up:
cmp al,0x50
jne hg_key_not_down
mov dx,0x0002
jmp hg_key_apply
hg_key_not_down:
cmp al,0x4b
jne hg_key_not_left
mov dx,0x0004
jmp hg_key_apply
hg_key_not_left:
cmp al,0x4d
jne hg_key_finish
mov dx,0x0008
hg_key_apply:
or dx,dx
jz hg_key_finish
test ah,0x80
jnz hg_key_release
or [keys_down],dx
jmp hg_key_finish
hg_key_release:
not dx
and [keys_down],dx
hg_key_finish:
mov byte [key_extended],0
hg_keyboard_ack:
in al,0x61
mov ah,al
or al,0x80
out 0x61,al
mov al,ah
out 0x61,al
mov al,0x20
out 0x20,al
pop ds
popa
iret
hg_keyboard_library_end:
ret
hg_level_library:
; Scale 250 levels, keep eight active enemies, and stream reinforcements
jmp hg_level_library_end
hg_start_level:
pusha
mov word [player_x],640
mov word [player_y],640
mov byte [player_angle],0
mov byte [player_health],100
mov byte [game_state],0
mov byte [shot_flash],0
mov byte [crosshair_color],15
mov word [frame_count],0
mov word [shot_cooldown],0
mov word [center_wall_distance],48
mov byte [spawn_cursor],0
mov word [music_timer],0
mov byte [key_ready],0
mov byte [level_continue_armed],0
xor ax,ax
mov al,[current_level]
dec ax
mov bx,5
mul bx
shr ax,2
add ax,5
mov [level_enemy_total],ax
mov [level_enemies_remaining],ax
xor si,si
hg_clear_enemy_slots:
mov byte [enemy_health+si],0
inc si
cmp si,8
jb hg_clear_enemy_slots
mov ax,[level_enemy_total]
cmp ax,8
jbe hg_active_count_ready
mov ax,8
hg_active_count_ready:
mov [enemies_alive],al
mov dx,[level_enemy_total]
sub dx,ax
mov [spawn_remaining],dx
xor si,si
xor di,di
mov cl,[enemies_alive]
xor ch,ch
jcxz hg_level_spawn_done
hg_level_spawn_loop:
call hg_spawn_enemy_slot
inc si
add di,2
loop hg_level_spawn_loop
hg_level_spawn_done:
popa
ret

hg_spawn_enemy_slot:
push ax
push bx
xor bx,bx
mov bl,[spawn_cursor]
and bl,7
shl bx,1
mov ax,[spawn_x_table+bx]
mov [enemy_x+di],ax
mov ax,[spawn_y_table+bx]
mov [enemy_y+di],ax
mov byte [enemy_health+si],3
inc byte [spawn_cursor]
and byte [spawn_cursor],7
pop bx
pop ax
ret

hg_finish_level:
cmp byte [current_level],250
jae hg_campaign_complete
mov byte [game_state],3
mov byte [crosshair_color],0
mov byte [shot_flash],0
mov byte [key_ready],0
mov byte [level_continue_armed],0
call hg_sound_win
ret

hg_advance_level:
cmp byte [current_level],250
jae hg_campaign_complete
inc byte [current_level]
call hg_start_level
ret
hg_campaign_complete:
mov byte [game_state],2
mov byte [crosshair_color],0
call hg_sound_win
ret

spawn_x_table dw 1152,3456,896,2944,1920,3712,1664,3200
spawn_y_table dw 640,1408,2688,3456,896,2688,3456,3456
hg_level_library_end:
ret
__oc_functions_end:
