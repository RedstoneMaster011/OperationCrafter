; BLOCK DATA: player, monsters, map, ray workspace, HUD strings
jmp after_define_word_1001
player_x dw 640
after_define_word_1001:
jmp after_define_word_1002
player_y dw 640
after_define_word_1002:
jmp after_define_word_1003
score dw 0
after_define_word_1003:
jmp after_define_word_1004
frame_count dw 0
after_define_word_1004:
jmp after_define_word_1005
shot_cooldown dw 0
after_define_word_1005:
jmp after_define_word_1006
random_seed dw 0xace1
after_define_word_1006:
jmp after_define_word_1007
candidate_x dw 0
after_define_word_1007:
jmp after_define_word_1008
candidate_y dw 0
after_define_word_1008:
jmp after_define_word_1009
center_wall_distance dw 48
after_define_word_1009:
jmp after_define_word_1010
ray_x dw 0
after_define_word_1010:
jmp after_define_word_1011
ray_y dw 0
after_define_word_1011:
jmp after_define_word_1012
ray_distance dw 0
after_define_word_1012:
jmp after_define_word_1013
ray_height dw 0
after_define_word_1013:
jmp after_define_word_1014
ray_top dw 0
after_define_word_1014:
jmp after_define_word_1015
draw_x dw 0
after_define_word_1015:
jmp after_define_word_1016
draw_y dw 0
after_define_word_1016:
jmp after_define_word_1017
draw_w dw 0
after_define_word_1017:
jmp after_define_word_1018
draw_h dw 0
after_define_word_1018:
jmp after_define_word_1019
vector_x dw 0
after_define_word_1019:
jmp after_define_word_1020
vector_y dw 0
after_define_word_1020:
jmp after_define_word_1021
projection_forward dw 0
after_define_word_1021:
jmp after_define_word_1022
projection_side dw 0
after_define_word_1022:
jmp after_define_word_1023
projection_x dw 0
after_define_word_1023:
jmp after_define_word_1024
projection_h dw 0
after_define_word_1024:
jmp after_define_word_1025
best_distance dw 0xffff
after_define_word_1025:
jmp after_define_word_1026
enemy_head_h dw 0
after_define_word_1026:
jmp after_define_word_1027
enemy_body_h dw 0
after_define_word_1027:
jmp after_define_word_1028
enemy_body_w dw 0
after_define_word_1028:
jmp after_define_word_1029
enemy_body_x dw 0
after_define_word_1029:
jmp after_define_word_1030
enemy_body_y dw 0
after_define_word_1030:
jmp after_define_word_1031
keys_down dw 0
after_define_word_1031:
jmp after_define_word_1032
text_x dw 0
after_define_word_1032:
jmp after_define_word_1033
text_y dw 0
after_define_word_1033:
jmp after_define_word_1034
level_enemy_total dw 5
after_define_word_1034:
jmp after_define_word_1035
level_enemies_remaining dw 5
after_define_word_1035:
jmp after_define_word_1036
spawn_remaining dw 0
after_define_word_1036:
jmp after_define_word_1037
music_timer dw 0
after_define_word_1037:
jmp after_define_word_1038
music_last_tick dw 0
after_define_word_1038:
jmp after_define_byte_1039
player_angle db 0
after_define_byte_1039:
jmp after_define_byte_1040
player_health db 100
after_define_byte_1040:
jmp after_define_byte_1041
game_state db 0
after_define_byte_1041:
jmp after_define_byte_1042
shot_flash db 0
after_define_byte_1042:
jmp after_define_byte_1043
enemies_alive db 5
after_define_byte_1043:
jmp after_define_byte_1044
key_ready db 0
after_define_byte_1044:
jmp after_define_byte_1045
last_key db 0
after_define_byte_1045:
jmp after_define_byte_1046
crosshair_color db 15
after_define_byte_1046:
jmp after_define_byte_1047
ray_column db 0
after_define_byte_1047:
jmp after_define_byte_1048
ray_angle db 0
after_define_byte_1048:
jmp after_define_byte_1049
wall_tile db 0
after_define_byte_1049:
jmp after_define_byte_1050
draw_color db 0
after_define_byte_1050:
jmp after_define_byte_1051
best_enemy db 0xff
after_define_byte_1051:
jmp after_define_byte_1052
current_enemy db 0
after_define_byte_1052:
jmp after_define_byte_1053
key_extended db 0
after_define_byte_1053:
jmp after_define_byte_1054
text_color db 15
after_define_byte_1054:
jmp after_define_byte_1055
current_level db 1
after_define_byte_1055:
jmp after_define_byte_1056
spawn_cursor db 0
after_define_byte_1056:
jmp after_define_byte_1057
music_index db 0
after_define_byte_1057:
jmp after_define_byte_1058
music_enabled db 1
after_define_byte_1058:
jmp after_define_byte_1059
level_continue_armed db 0
after_define_byte_1059:
jmp after_word_array_1060
zbuffer times 40 dw 48
after_word_array_1060:
jmp after_word_array_1061
enemy_x times 8 dw 0
after_word_array_1061:
jmp after_word_array_1062
enemy_y times 8 dw 0
after_word_array_1062:
jmp after_byte_array_1063
enemy_health times 8 db 0
after_byte_array_1063:
jmp after_raw_bytes_1064
world_map db 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,1,1,1,0,0,1,1,1,0,1,1,1,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,1,0,0,0,0,0,0,1,0,0,0,1,1,0,0,0,1,0,1,1,1,1,0,1,0,0,0,1,1,0,0,0,1,0,0,0,0,0,0,1,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,1,1,0,1,1,0,0,1,1,0,1,1,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1
after_raw_bytes_1064:
jmp after_raw_bytes_1065
hud_hp_text db "HP:",0
after_raw_bytes_1065:
jmp after_raw_bytes_1066
hud_level_text db "LV:",0
after_raw_bytes_1066:
jmp after_raw_bytes_1067
hud_enemy_text db "EN:",0
after_raw_bytes_1067:
jmp after_raw_bytes_1068
hud_score_text db "SCORE:",0
after_raw_bytes_1068:
jmp after_raw_bytes_1069
dead_text db "YOU DIED",0
after_raw_bytes_1069:
jmp after_raw_bytes_1070
win_text db "ALL 250 LEVELS CLEARED",0
after_raw_bytes_1070:
jmp after_raw_bytes_1071
restart_text db "PRESS R TO RESTART",0
after_raw_bytes_1071:
jmp after_raw_bytes_1072
level_complete_text db "LEVEL COMPLETE",0
after_raw_bytes_1072:
jmp after_raw_bytes_1073
next_level_text db "PRESS ANY KEY FOR NEXT LEVEL",0
after_raw_bytes_1073:
; Custom block is required only for signed 8.8 word lookup tables
jmp hg_trig_data_end
cos_table dw 256,255,251,245,237,226,213,198,181,162,142,121,98,74,50,25,0,-25,-50,-74,-98,-121,-142,-162,-181,-198,-213,-226,-237,-245,-251,-255,-256,-255,-251,-245,-237,-226,-213,-198,-181,-162,-142,-121,-98,-74,-50,-25,0,25,50,74,98,121,142,162,181,198,213,226,237,245,251,255
sin_table dw 0,25,50,74,98,121,142,162,181,198,213,226,237,245,251,255,256,255,251,245,237,226,213,198,181,162,142,121,98,74,50,25,0,-25,-50,-74,-98,-121,-142,-162,-181,-198,-213,-226,-237,-245,-251,-255,-256,-255,-251,-245,-237,-226,-213,-198,-181,-162,-142,-121,-98,-74,-50,-25
hg_trig_data_end:
