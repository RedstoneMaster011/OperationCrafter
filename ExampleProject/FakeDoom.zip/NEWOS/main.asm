[org 0x7c00]
KERNEL_OFFSET equ 0x1000

jmp 0:start

start:
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7c00
    
    mov [0x7e00], dl

    call load_kernel
    
    jmp 0x0000:KERNEL_OFFSET

%include "disk.asm"

load_kernel:
    mov bx, KERNEL_OFFSET
    mov dh, 17
    mov dl, [0x7e00]
    call disk_load
    ret

times 510-($-$$) db 0
dw 0xaa55
