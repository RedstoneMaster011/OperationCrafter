jmp disk_setup_done_1
disk_load:
    push dx
    mov si, 3
.disk_retry:
    mov ah, 0x02
    mov al, dh
    xor ch, ch
    xor dh, dh
    mov cl, 0x02
    mov dl, [0x7e00]
    int 0x13
    jnc .disk_done
    xor ax, ax
    int 0x13
    dec si
    jnz .disk_retry
    mov ah, 0x0e
    mov al, 'E'
    int 0x10
    cli
.disk_error_halt:
    hlt
    jmp .disk_error_halt
.disk_done:
    pop dx
    ret
disk_setup_done_1:
